package com.example.criaturas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CriaturasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CriaturasApplication.class, args);
	}

}
