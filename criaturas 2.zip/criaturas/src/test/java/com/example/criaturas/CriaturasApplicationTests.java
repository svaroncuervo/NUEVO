package com.example.criaturas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CriaturasApplicationTests {

	@Test
	void contextLoads() {
	}

}
